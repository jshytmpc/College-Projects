public class Subscriber {
    private String firstname;
    private String lastname;
    private String middlename;
    private String suffix;
    private String birthday;
    private String sex;
    private String nationality;
    private String province;
    private String city;
    private int unit;
    private String street;
    private String barangay;
    private int zipcode;
    private String ownership;

    public Subscriber(String firstname, String lastname, String middlename, String suffix, String birthday, String sex, String nationality, String province, String city, int unit, String street, String barangay, int zipcode, String ownership) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.middlename = middlename;
        this.suffix = suffix;
        this.birthday = birthday;
        this.sex = sex;
        this.nationality = nationality;
        this.province = province;
        this.city = city;
        this.unit = unit;
        this.street = street;
        this.barangay = barangay;
        this.zipcode = zipcode;
        this.ownership = ownership;
    }


    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public String getSuffix() {
        return suffix;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getSex() {
        return sex;
    }

    public String getNationality() {
        return nationality;
    }

    public String getProvince() {
        return province;
    }

    public String getCity() {
        return city;
    }

    public int getUnit() {
        return unit;
    }

    public String getStreet() {
        return street;
    }

    public String getBarangay() {
        return barangay;
    }

    public int getZipcode() {
        return zipcode;
    }

    public String getOwnership() {
        return ownership;
    }
}
